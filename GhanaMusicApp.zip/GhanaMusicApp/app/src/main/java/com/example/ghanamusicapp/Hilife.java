package com.example.ghanamusicapp;

import android.os.Bundle;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class Hilife extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.music_list);
        ArrayList<Music> music= new ArrayList<Music>();
        music.add(new Music("Kojo Antwi", "Anokye     1989"));
        music.add(new Music("Kojo Antwi", "Mr Music Man      1992"));
        music.add(new Music("Kojo Antwi", "Superman     1998"));
        music.add(new Music("Kojo Antwi", "Akuaba    2000"));
        music.add(new Music("Kojo Antwi", "Tattoo      2006"));
        music.add(new Music("Daddy Lumba", "Obi Ate Meso Bo     1990"));
        music.add(new Music("Kojo Antwi", "Hwan na Otene     1996"));
        music.add(new Music("Kojo Antwi", "Aben Wo Ha    1998"));
        music.add(new Music("Kojo Antwi", "Anokye     1989"));
        music.add(new Music("Kojo Antwi", "Mr Music Man      1992"));
        music.add(new Music("Kojo Antwi", "Superman     1998"));
        music.add(new Music("Kojo Antwi", "Akuaba    2000"));
        music.add(new Music("Kojo Antwi", "Tattoo      2006"));
        music.add(new Music("Daddy Lumba", "Obi Ate Meso Bo     1990"));
        music.add(new Music("Kojo Antwi", "Hwan na Otene     1996"));
        music.add(new Music("Kojo Antwi", "Aben Wo Ha    1998"));
        music.add(new Music("Kojo Antwi", "Anokye     1989"));
        music.add(new Music("Kojo Antwi", "Mr Music Man      1992"));
        music.add(new Music("Kojo Antwi", "Superman     1998"));
        music.add(new Music("Kojo Antwi", "Akuaba    2000"));
        music.add(new Music("Kojo Antwi", "Tattoo      2006"));
        music.add(new Music("Daddy Lumba", "Obi Ate Meso Bo     1990"));
        music.add(new Music("Kojo Antwi", "Hwan na Otene     1996"));
        music.add(new Music("Kojo Antwi", "Aben Wo Ha    1998"));
        music.add(new Music("Kojo Antwi", "Anokye     1989"));
        music.add(new Music("Kojo Antwi", "Mr Music Man      1992"));
        music.add(new Music("Kojo Antwi", "Superman     1998"));
        music.add(new Music("Kojo Antwi", "Akuaba    2000"));
        music.add(new Music("Kojo Antwi", "Tattoo      2006"));
        music.add(new Music("Daddy Lumba", "Obi Ate Meso Bo     1990"));
        music.add(new Music("Kojo Antwi", "Hwan na Otene     1996"));
        music.add(new Music("Kojo Antwi", "Aben Wo Ha    1998"));

        MusicAdapter adapter = new MusicAdapter(this, music);
        ListView listView = (ListView) findViewById(R.id.music_list);
        listView.setAdapter(adapter);
    }
}
