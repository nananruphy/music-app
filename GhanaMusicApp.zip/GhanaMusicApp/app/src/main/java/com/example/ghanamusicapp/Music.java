package com.example.ghanamusicapp;

public class Music {
    /** Artist name */
    private String artist;

    /** Album title and year */
    private String album;

    /**
     * Create a new Music object.
     */
    public Music(String artist, String album) {
        artist = artist;
        album = album;
    }

    /**
     * Get the artist for the music.
     */
    public String getArtist() {
        return artist;
    }

    /**
     * Get the album for the music.
     */
    public String getAlbum() {
        return album;
    }

}
